#!/bin/bash

[ -d $HOME"/.config" ] || mkdir -p $HOME"/.config"
[ -d $HOME"/.config/bspwm" ] || mkdir -p $HOME"/.config/bspwm"
[ -d $HOME"/.config/sxkhd" ] || mkdir -p $HOME"/.config/sxkhd"
[ -d $HOME"/.config/polybar" ] || mkdir -p $HOME"/.config/polybar"

cp -Rf ~/.config ~/.config-backup-$(date +%Y.%m.%d-%H.%M.%S)
cp -arf bspwm ~/.config/bspwm
cp -arf sxhkd ~/.config/sxhkd
cp -arf polybar ~/.config/polybar

#cd test2
#cd bspwm
#cp -r * ~/mythetest
#cd ..
#cd ..
#pwd
